#ifndef _I386_MATH_EMU_H
#define _I386_MATH_EMU_H

// Don't really need anything in here.

#endif

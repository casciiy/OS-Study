/************************************************************************ 
  MCDINFO  Get CD Image                 v00.10.00
  Forever Young Software      Benjamin David Lunt

  This utility was desinged for use with Bochs to get an
    image from a CDROM.

  Bochs is located at:
    http://bochs.sourceforge.net

  I designed this program to be used for testing my own OS,
   though you are welcome to use it any way you wish.

  Please note that I release it and it's code for others to
   use and do with as they want.  You may copy it, modify it,
   do what ever you want with it as long as you release the
   source code and display this entire comment block in your
   source or documentation file.
   (you may add to this comment block if you so desire)

  Please use at your own risk.  I do not specify that this
   code is correct and unharmful.  No warranty of any kind
   is given for its release.

  I take no blame for what may or may not happen by using
   this code with your purposes.

  'nuff of that!  You may modify this to your liking and if you
   see that it will help others with their use of Bochs, please
   send the revised code to fys@cybertrails.com.  I will then
   release it as I have this one.

  P.S.  Please don't laugh at my code :)  I didn't spend but
   a few minutes on this.  BXimage just wasn't working for my
   needs, so here it is.

  You may get the latest and greatest at:
    http://www.cybertrails.com/~fys/mtools.htm

  Thanks, and thanks to those who contributed to Bochs....

  ********************************************************

  Things to know:
  - 
  
  ********************************************************

  Compiles as is with MS VC++ 6.x         (Win32 .EXE file)

	// ****** I am sure it will.  You just have to copy all those
	//   Windows.h files.... yeekkk.
  To compile using DJGPP:  (http://www.delorie.com/djgpp/)
     gcc -Os mkdosfs.c -o mkdosfs.exe -s  (DOS .EXE requiring DPMI)

	// ****** Requires an NT machine.  No DOS support here *****
  //Compiles as is with MS QC2.5            (TRUE DOS only)

  ********************************************************

  Usage:
    Nothing.  Just run it...

************************************************************************/

// don't know which ones are needed or not needed.  I just copied them
//  across from another project. :)
#include <ctype.h>
#include <conio.h>
#include <stdio.h>
#include <errno.h>
#include <memory.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <limits.h>
#include <math.h>
#include <time.h>

#include <windows.h>

#include "mgetcd.h"   // our include

#define SECT_SIZE 2048

HANDLE cdFile, imgFile;
char drive[16], drvletter;
char filename[128], temp[128];
unsigned long ntemp, pos, ul;
unsigned char buf[SECT_SIZE];

//// ***** WARNING.  At current, this only works on NT machines **********

int main() {

	// print start string
	printf(strtstr);

	printf("\n *** Warning.  This currently only works on WinNT machines ***");
	printf("\n   Continue (Yes or No): ");
	gets(temp);
	if (strcmp(temp, "Y") && strcmp(temp, "Yes") && strcmp(temp, "YES"))
		return 0xFF;

	printf("\n  Filename of image to create [cdrom.img]: ");
	gets(filename);
	if (!strlen(filename)) strcpy(filename, "cdrom.img");

	do {
		printf("                         Drive letter [d]: ");
		gets(temp);
		if (!strlen(temp))
			drvletter = 'd';
		else
			drvletter = tolower(temp[0]);
	} while ((drvletter < 'd') || (drvletter > 'z'));
	sprintf(drive, "\\\\.\\%c:", drvletter);

	imgFile = CreateFile(filename, GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_ALWAYS, FILE_FLAG_RANDOM_ACCESS, NULL);
	if (imgFile == (void *)0xFFFFFFFF) {} // TODO: error

	cdFile = CreateFile((char *)&drive, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, FILE_FLAG_RANDOM_ACCESS, NULL);
	if (cdFile == (void *)0xFFFFFFFF) {} // TODO: error

	pos = SetFilePointer(cdFile, (16*SECT_SIZE), NULL, SEEK_SET);
	ReadFile(cdFile, (void *) &pvd, SECT_SIZE, (unsigned long *) &ntemp, NULL);
	if (ntemp == 0) {} // TODO: error

	printf("\n Found %i sectors\n\n", pvd.num_lbas);
	
	pos = SetFilePointer(cdFile, 0, NULL, SEEK_SET);
	for (ul=0; ul < pvd.num_lbas; ul++) {
		printf("\r Sector %i of %i", ul, pvd.num_lbas);
		ReadFile(cdFile, (void *) buf, SECT_SIZE, (unsigned long *) &ntemp, NULL);
		WriteFile(imgFile, (void *) buf, SECT_SIZE, (unsigned long *) &ntemp, NULL);
	}

	CloseHandle(cdFile);
	CloseHandle(imgFile);
	
	return 0x00;
}
